apiVersion: v1
items:
- apiVersion: config.gatekeeper.sh/v1alpha1
  kind: Config
  metadata:
    annotations:
      config-installed-by: azure-policy-addon
    creationTimestamp: "2025-01-25T22:45:17Z"
    generation: 1
    name: config
    namespace: gatekeeper-system
    resourceVersion: "2774"
    uid: 18369d08-605b-46a4-93c6-3cbeec799508
  spec:
    match:
    - excludedNamespaces:
      - kube-system
      - gatekeeper-system
      - azure-arc
      - arc-osm-system
      processes:
      - audit
    - excludedNamespaces:
      - kube-system
      - gatekeeper-system
      - azure-arc
      - arc-osm-system
      processes:
      - webhook
kind: List
metadata:
  resourceVersion: ""
