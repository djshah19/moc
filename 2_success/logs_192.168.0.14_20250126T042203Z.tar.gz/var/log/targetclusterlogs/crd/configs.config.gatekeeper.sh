apiVersion: v1
items:
- apiVersion: config.gatekeeper.sh/v1alpha1
  kind: Config
  metadata:
    annotations:
      config-installed-by: azure-policy-addon
    creationTimestamp: "2025-01-25T23:11:21Z"
    generation: 1
    name: config
    namespace: gatekeeper-system
    resourceVersion: "2779"
    uid: c097b84a-2b4e-481f-93b6-dde96bfc0121
  spec:
    match:
    - excludedNamespaces:
      - kube-system
      - gatekeeper-system
      - azure-arc
      - arc-osm-system
      processes:
      - audit
    - excludedNamespaces:
      - kube-system
      - gatekeeper-system
      - azure-arc
      - arc-osm-system
      processes:
      - webhook
kind: List
metadata:
  resourceVersion: ""
